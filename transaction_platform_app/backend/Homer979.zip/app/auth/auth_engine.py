from flask import Blueprint, request, jsonify
import boto3

auth_blueprint = Blueprint('auth', __name__)  # No prefix

COGNITO_CONFIG = {
   'user_pool_id': 'us-west-2_JnwmUHLzc',
   'client_id': '47l1p0md5fpj3adg86no3h0sk6',
   'region': 'us-west-2'
}

def get_cognito_client():
   return boto3.client('cognito-idp', region_name=COGNITO_CONFIG['region'])

@auth_blueprint.route('/api/auth/cognito-auth', methods=['POST'])
def cognito_auth():
   print("\n" + "="*50)  # Create a visual separator line
   print(f"🚀 FOUND ROUTE: {request.url}")  # Shows full URL including host
   print(f"🛣️  ENDPOINT: {request.endpoint}")  # Shows route name
   print("="*50 + "\n")  # Close the visual separator
   
   try:
       data = request.get_json()
       print("DEBUG: Received data:", data)
       
       identifier = data.get('identifier')
       password = data.get('password')
       
       if not identifier or not password:
           return jsonify({
               'error': 'Username/email and password are required'
           }), 400
           
       cognito_client = get_cognito_client()
       
       try:
           auth_response = cognito_client.initiate_auth(
               ClientId=COGNITO_CONFIG['client_id'],
               AuthFlow='USER_PASSWORD_AUTH',
               AuthParameters={
                   'USERNAME': identifier,
                   'PASSWORD': password
               }
           )
           
           return jsonify({
               'success': True,
               'accessToken': auth_response['AuthenticationResult']['AccessToken'],
               'idToken': auth_response['AuthenticationResult']['IdToken'],
               'refreshToken': auth_response['AuthenticationResult']['RefreshToken'],
               'expiresIn': auth_response['AuthenticationResult']['ExpiresIn'],
               'userGroups': []
           }), 200
           
       except Exception as e:
           print(f"DEBUG: Cognito auth error: {str(e)}")
           return jsonify({
               'error': f'Authentication failed: {str(e)}'
           }), 500
           
   except Exception as e:
       print(f"DEBUG: General error: {str(e)}")
       return jsonify({
           'error': f'Server error: {str(e)}'
       }), 500

@auth_blueprint.route('/api/auth/logout', methods=['POST'])  # Standardized route pattern
def logout():
   print("\n" + "="*50)  # Create a visual separator line
   print(f"🚀 FOUND ROUTE: {request.url}")  # Shows full URL including host
   print(f"🛣️  ENDPOINT: {request.endpoint}")  # Shows route name
   print("="*50 + "\n")  # Close the visual separator
   
   try:
       return jsonify({'message': 'Successfully logged out'}), 200
   except Exception as e:
       print(f"DEBUG: Logout error: {str(e)}")
       return jsonify({
           'error': f'Logout failed: {str(e)}'
       }), 500
