from flask import Blueprint, request, jsonify
import requests

auth_blueprint = Blueprint('auth', __name__)

COGNITO_CONFIG = {
    'user_pool_id': 'us-west-2_JnwmUHLzc',
    'client_id': '47l1p0md5fpj3adg86no3h0sk6',
    'region': 'us-west-2'
}

@auth_blueprint.route('/api/auth/opendoor', methods=['POST'])
def open_door():
    print("\n" + "="*50)
    print(f"🚀 FOUND ROUTE: {request.url}")
    print(f"🛣️  ENDPOINT: {request.endpoint}")
    print("="*50 + "\n")

    try:
        data = request.get_json()
        print("DEBUG: Received data:", data)

        identifier = data.get('identifier')
        password = data.get('password')

        if not identifier or not password:
            return jsonify({
                'error': 'Username/email and password are required'
            }), 400

        cognito_endpoint = f"https://cognito-idp.{COGNITO_CONFIG['region']}.amazonaws.com"
        headers = {
            'X-Amz-Target': 'AWSCognitoIdentityProviderService.InitiateAuth',
            'Content-Type': 'application/x-amz-json-1.1'
        }
        
        auth_data = {
            'AuthFlow': 'USER_PASSWORD_AUTH',
            'ClientId': COGNITO_CONFIG['client_id'],
            'AuthParameters': {
                'USERNAME': identifier,
                'PASSWORD': password
            }
        }

        response = requests.post(cognito_endpoint, json=auth_data, headers=headers)
        auth_response = response.json()

        return jsonify({
            'success': True,
            'accessToken': auth_response['AuthenticationResult']['AccessToken'],
            'idToken': auth_response['AuthenticationResult']['IdToken'],
            'refreshToken': auth_response['AuthenticationResult']['RefreshToken'],
            'expiresIn': auth_response['AuthenticationResult']['ExpiresIn'],
            'userGroups': []
        }), 200

    except Exception as e:
        print(f"DEBUG: Auth error: {str(e)}")
        return jsonify({
            'error': f'Authentication failed: {str(e)}'
        }), 500

@auth_blueprint.route('/api/auth/logout', methods=['POST'])
def logout():
    print("\n" + "="*50)
    print(f"🚀 FOUND ROUTE: {request.url}")
    print(f"🛣️  ENDPOINT: {request.endpoint}")
    print("="*50 + "\n")

    try:
        return jsonify({'message': 'Successfully logged out'}), 200
    except Exception as e:
        print(f"DEBUG: Logout error: {str(e)}")
        return jsonify({
            'error': f'Logout failed: {str(e)}'
        }), 500
