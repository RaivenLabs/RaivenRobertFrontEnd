from flask import Blueprint, request, jsonify


auth_blueprint = Blueprint('auth', __name__)  # No prefix




@auth_blueprint.route('/api/auth/opendoor', methods=['POST'])
def open_door():
   print("\n" + "="*50)  # Create a visual separator line
   print(f"🚀 FOUND ROUTE: {request.url}")  # Shows full URL including host
   print(f"🛣️  ENDPOINT: {request.endpoint}")  # Shows route name
   print("="*50 + "\n")  # Close the visual separator
   
   